#include "Material.h"



Material::Material()	{}


Material::~Material()	{}

void Material::SetAmbient(float a, float b, float c, float d) {
	ambient[0] = a;
	ambient[1] = b;
	ambient[2] = c;
	ambient[3] = d;
}

void Material::SetDiffuse(float a, float b, float c, float d) {
	diffuse[0] = a;
	diffuse[1] = b;
	diffuse[2] = c;
	diffuse[3] = d;
}